#include "../include/idt.h"
#include "../include/util.h"

void set_idt_gate(int n, uint32 handler) {
    idt[n].low_offset = low_16(handler);
    idt[n].sel = KERNEL_CS;
    idt[n].always0 = 0;
    idt[n].flags = 0x8E; 
    idt[n].high_offset = high_16(handler);
}
void set_int(int i, uint32_t addr)
{
	printf("Installing INT#%d to address: 0x%x\n", i, addr);
	set_idt_gate(i, addr);
    set_idt();
}
void set_idt() {
    idt_reg.base = (uint32) &idt;
    idt_reg.limit = IDT_ENTRIES * sizeof(idt_gate_t) - 1;
    __asm__ __volatile__("lidtl (%0)" : : "r" (&idt_reg));
}
