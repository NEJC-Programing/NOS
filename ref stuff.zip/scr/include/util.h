#ifndef UTIL_H
#define UTIL_H

#include "types.h"

void memory_copy(char *source, char *dest, int nbytes);
void memory_set(uint8 *dest, uint8 val, uint32 len);
void int_to_ascii(int n, char str[]);  
int str_to_int(string ch);
string int_to_string(int n);
void * malloc(int nbytes);      
void * clean(int size);
char *strcpy(char *to, const char *from);
void memcpy(char *source, char *dest, int nbytes);
void memset(uint8 *dest, uint8 val, uint32 len);
char *strcpy(char *to, const char *from);
#endif
