#ifndef XXD_H
#define XXD_H

#define DUMP_COLS 16

void xxd(void * data, unsigned int len);

#endif
