#ifndef USERMODE_H
#define USERMODE_H
#include <system.h>

extern void switch_to_user();

void enter_usermode();
#endif
