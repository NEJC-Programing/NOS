#ifndef KEYBOARD_H
#define KEYBOARD_H
#include <system.h>

void keyboard_handler(register_t * r);

void keyboard_init();

#endif
