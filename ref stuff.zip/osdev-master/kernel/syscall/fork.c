#include <syscall.h>

/*
 * Syscall fork
 * */
pid_t fork() {

}
