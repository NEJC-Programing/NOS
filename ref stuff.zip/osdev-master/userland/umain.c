
int umain() {
    int a = 0;
    a++;
    return 0;
}
