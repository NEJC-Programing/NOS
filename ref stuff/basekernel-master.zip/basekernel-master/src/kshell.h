#ifndef KSHELL_H
#define KSHELL_H

int kshell_launch();

#endif
