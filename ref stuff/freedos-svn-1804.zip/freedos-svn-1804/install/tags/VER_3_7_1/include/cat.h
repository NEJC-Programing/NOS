int
cat_file (const char *filename, int maxlines);
