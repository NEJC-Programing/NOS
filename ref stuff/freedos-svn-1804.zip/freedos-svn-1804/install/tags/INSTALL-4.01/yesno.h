int yesno (const char *yn);
