void
splitdir (char *fulldir, char *drive, char *dir);
