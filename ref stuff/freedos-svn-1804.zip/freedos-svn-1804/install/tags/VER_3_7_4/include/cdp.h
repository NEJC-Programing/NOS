/* Make sure destination directory exists (or create if not)       */
/* This fixes bug, where if path does not exist then install fails */
void createdestpath(char *destdir);
