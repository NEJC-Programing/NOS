int getch_yn (void);
