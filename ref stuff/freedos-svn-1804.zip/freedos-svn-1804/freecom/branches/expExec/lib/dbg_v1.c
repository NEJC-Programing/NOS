/* $id$
	Some variables for debugging.
*/

#include "../config.h"

char *dbg_trace = 0;
