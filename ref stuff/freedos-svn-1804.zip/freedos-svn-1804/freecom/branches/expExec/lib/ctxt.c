/* $Id: ctxt.c 190 2001-04-12 00:36:10Z skaus $

	Dynamic context of the FreeCOM instance
*/

#include "../config.h"

#include "../include/context.h"

ctxt_t ctxt = 0;
