/*	$id$
	$Locker$	$Name$	$State$

	Variables for output strings

	$Log$
	Revision 1.1.2.1  2001/07/16 20:28:38  skaus
	Update #9

 */

#include "../config.h"

#include <stdio.h>

#include "../include/misc.h"

FILE *XerrStream = 0;
FILE *XoutStream = 0;
