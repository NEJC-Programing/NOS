/* $id$

	Shared local/global flags

*/

#include "../config.h"

#include "../include/context.h"

ctxt_shared_flags_t ctxtSharedFlags;
