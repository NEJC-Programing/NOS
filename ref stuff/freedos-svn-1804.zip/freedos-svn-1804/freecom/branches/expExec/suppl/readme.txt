This version of FreeCOM has been compiled and linked with the SUPPL
library, which is available from the Steffen's site at

ftp://ftp-fd.inf.fh-rhein-sieg.de/pub/freedos/local/ALPHA
-or-
http://www2.inf.fh-rhein-sieg.de/~skaise2a/ska/sources.html#suppl

A version pre-compiled for Turbo-C++ v1.01 can be downloaded
from ftp://freedos.sourceforge.net/pub/freedos/freecom/suppl.zip

The last revision of SUPPL linked to FreeCOM was created on
Time stamp: GMT Thu Apr 12 01:57:24 2001
