gdb os_kernel -ex "target remote localhost:1234"
