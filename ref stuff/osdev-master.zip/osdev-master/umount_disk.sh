#!/bin/bash
sudo umount /mnt
