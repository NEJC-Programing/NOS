#include <tcp.h>


void tcp_send_packet(uint8_t * dst_ip, uint16_t src_port, uint16_t dst_port, void * data, int len) {

}

void tcp_handle_packet(tcp_packet_t * packet) {

}
