#include <usermode.h>

void enter_usermode() {
    switch_to_user();
}
