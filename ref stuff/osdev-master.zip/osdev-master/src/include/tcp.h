#ifndef TCP_H
#define TCP_H
#include <system.h>

typedef struct tcp_packet {

}tcp_packet_t;

#endif
