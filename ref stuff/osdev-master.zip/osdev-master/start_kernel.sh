./update_image.sh
./run_bochs.sh
