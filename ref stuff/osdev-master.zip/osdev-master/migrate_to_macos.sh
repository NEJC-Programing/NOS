./compile.sh
cp -r * /vagrant/osdev/
