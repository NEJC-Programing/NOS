#!/bin/bash
cd src
make clean && make
