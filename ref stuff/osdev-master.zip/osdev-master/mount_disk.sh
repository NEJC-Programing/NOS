#!/bin/bash
sudo mount ext2_hda.img /mnt
