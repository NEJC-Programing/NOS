find -iregex '.*\.\(c\|asm\|h\)$' | xargs wc -l
