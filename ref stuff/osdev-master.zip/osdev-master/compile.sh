#!/bin/bash
cd src
make
